# Corrections C2 / C3 / H1 / H2 / H3 — Mise en ligne

## Contenu du zip

```
robots.txt                → remplace ton robots.txt actuel (dédupliqué, sans conflit)
functions/_middleware.js  → à placer dans functions/ à la racine du projet Pages
                            → ajoute X-Robots-Tag: noindex sur *.pages.dev uniquement
404.html                  → à la racine : Cloudflare Pages le sert automatiquement
                            avec un vrai statut 404 (fin du soft-404)
sitemap.xml               → remplace l'actuel : 25 URLs d'origine + études de cas
                            + hub réglementation + 118 chapitres = 145 URLs
pages-corrigees/          → 7 pages avec canonical / Open Graph / meta description
                            ajoutés juste avant </head>, sans rien toucher d'autre :
                            kit-gratuit, kit-signaletique, mentions-legales,
                            sam-incendie, secteurs (canonical + OG),
                            cours, exercices (OG seulement)
```

## Étape manuelle — la seule que je ne peux pas faire à ta place (5 min)

Le bloc « Cloudflare Managed Content » qui bloque GPTBot et ClaudeBot est
**injecté par Cloudflare devant ton fichier**. Remplacer le fichier ne suffit pas :

1. Dashboard Cloudflare → zone **samincendie.fr** → **Security → Bots**
   (ou **Settings** selon l'interface) → désactive **« Manage robots.txt »**
   / « Block AI bots » (le réglage qui gère les Content Signals).
2. Toujours dans **Security → Bots**, vérifie que **« Block AI Scrapers and
   Crawlers »** est sur *Off* ou *Only on hostnames with ads* — sinon le WAF
   bloque les crawlers IA même avec un robots.txt parfait.
3. Vérification après déploiement :
   `https://samincendie.fr/robots.txt` ne doit plus contenir
   « BEGIN Cloudflare Managed content » ni aucun `ClaudeBot / Disallow`.

## Vérifications finales (2 min)

- `curl -I https://samincendie.fr/page-qui-nexiste-pas.html` → doit répondre **404**
- `curl -I https://9c9b98ec.samincendie2.pages.dev/` → doit contenir
  **x-robots-tag: noindex, nofollow**
- Search Console → Sitemaps → soumettre `sitemap.xml` à nouveau
- Search Console → Suppressions → demander le retrait de
  `9c9b98ec.samincendie2.pages.dev` (accélère la désindexation, le noindex fait le reste)

## Correction du rapport d'audit

La homepage possède en réalité déjà son canonical — le rapport la comptait
à tort dans les pages à corriger (bug d'affichage de mon script d'analyse).
Le périmètre réel : 5 pages sans canonical, toutes corrigées ici.
