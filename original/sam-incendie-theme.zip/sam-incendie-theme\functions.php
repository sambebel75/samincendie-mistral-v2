<?php
/**
 * Sam Incendie — functions.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ---- Theme setup ---- */
function si_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );
    load_theme_textdomain( 'sam-incendie', get_template_directory() . '/languages' );

    register_nav_menus( [
        'primary' => __( 'Menu principal', 'sam-incendie' ),
        'footer'  => __( 'Menu footer', 'sam-incendie' ),
    ] );
}
add_action( 'after_setup_theme', 'si_setup' );

/* ---- Enqueue assets ---- */
function si_enqueue_assets() {
    // Google Fonts
    wp_enqueue_style(
        'si-google-fonts',
        'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&family=Open+Sans:ital,wght@0,400;0,600;1,400&display=swap',
        [],
        null
    );

    // Main stylesheet (style.css = theme CSS)
    wp_enqueue_style(
        'si-style',
        get_stylesheet_uri(),
        [ 'si-google-fonts' ],
        '1.0.0'
    );

    // Main JS
    wp_enqueue_script(
        'si-main',
        get_template_directory_uri() . '/js/main.js',
        [],
        '1.0.0',
        true  // load in footer
    );
}
add_action( 'wp_enqueue_scripts', 'si_enqueue_assets' );

/* ---- Helper : URL raccourcie ---- */
function si_url( $path = '' ) {
    return esc_url( home_url( '/' . ltrim( $path, '/' ) ) );
}

/* ---- Désactiver la barre d'admin en front-end (optionnel) ---- */
// add_filter( 'show_admin_bar', '__return_false' );
