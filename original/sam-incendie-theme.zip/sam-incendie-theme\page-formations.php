<?php
/**
 * Template Name: Formations
 * Template Post Type: page
 */
get_header(); ?>

<main>
  <section class="page-hero">
    <div class="container">
      <nav class="breadcrumb" aria-label="Fil d'Ariane">
        <a href="<?php echo si_url(); ?>">Accueil</a> <span aria-hidden="true">›</span> <span>Formations</span>
      </nav>
      <h1>Formation Sécurité Incendie</h1>
      <p>Des formations pratiques et réglementaires pour sensibiliser vos équipes, former vos équipiers de première intervention et assurer la conformité de votre établissement.</p>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="reglem__card" style="margin-bottom:32px; background:#fff8f0; border-left:4px solid #E67E22; border-radius:8px; padding:20px 24px;">
        <strong style="color:#d06b12;">📋 Obligation légale</strong>
        <p style="margin-top:8px; margin-bottom:0; color:#5a5a5a;">L'article <strong>R.4227-28 du Code du travail</strong> impose à tout employeur de prendre les mesures nécessaires pour que tout commencement d'incendie puisse être rapidement et efficacement combattu. Cela implique obligatoirement la <strong>formation des salariés</strong> désignés comme équipiers de première intervention.</p>
      </div>

      <div class="services__grid">
        <article class="service-card">
          <div class="service-card__icon service-card__icon--formation">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
          </div>
          <h2 class="service-card__title">Sensibilisation incendie — Tous publics</h2>
          <p class="service-card__text">Formation de sensibilisation pour l'ensemble du personnel, sans pré-requis. Comprendre les risques d'incendie, les comportements à adopter et utiliser les équipements de premier secours.</p>
          <ul class="service-card__list">
            <li>Durée : 2h à une demi-journée</li>
            <li>Théorie : triangle du feu, classes de feux</li>
            <li>Pratique : manipulation d'extincteurs</li>
            <li>Consignes d'évacuation et points de rassemblement</li>
          </ul>
          <a href="<?php echo si_url(); ?>#contact" class="service-card__link">Demander un devis →</a>
        </article>

        <article class="service-card service-card--featured">
          <div class="service-card__badge">Obligatoire ERP</div>
          <div class="service-card__icon service-card__icon--audit">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          </div>
          <h2 class="service-card__title">Formation EPI — Équipier de Première Intervention</h2>
          <p class="service-card__text">Formation réglementaire pour les salariés désignés comme EPI. À l'issue, ils sont capables d'intervenir immédiatement sur un début d'incendie et de guider l'évacuation.</p>
          <ul class="service-card__list">
            <li>Durée : 1 journée complète</li>
            <li>Cadre légal et responsabilités</li>
            <li>Techniques de lutte contre l'incendie</li>
            <li>Manœuvres extincteurs (feux réels recommandés)</li>
            <li>Attestation de formation remise</li>
          </ul>
          <a href="<?php echo si_url(); ?>#contact" class="service-card__link">Demander un devis →</a>
        </article>

        <article class="service-card">
          <div class="service-card__icon service-card__icon--info">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
          </div>
          <h2 class="service-card__title">Exercice d'évacuation encadré</h2>
          <p class="service-card__text">Organisation et animation d'un exercice d'évacuation incendie conforme à la réglementation, avec débriefing et rapport pour le registre de sécurité.</p>
          <ul class="service-card__list">
            <li>Minimum 2 exercices par an obligatoires</li>
            <li>Préparation et briefing de l'équipe</li>
            <li>Animation et chronométrage de l'évacuation</li>
            <li>Compte-rendu pour le registre de sécurité</li>
          </ul>
          <a href="<?php echo si_url(); ?>#contact" class="service-card__link">Demander un devis →</a>
        </article>

        <article class="service-card">
          <div class="service-card__icon service-card__icon--conseil">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
          </div>
          <h2 class="service-card__title">Formation référent sécurité incendie</h2>
          <p class="service-card__text">Programme de 2 jours pour former un référent interne capable de gérer la sécurité incendie de l'établissement : tenue du registre, organisation des formations, relations avec la commission.</p>
          <ul class="service-card__list">
            <li>Durée : 2 jours</li>
            <li>Réglementation ERP complète</li>
            <li>Gestion du registre de sécurité</li>
            <li>Préparation à la commission de sécurité</li>
          </ul>
          <a href="<?php echo si_url(); ?>#contact" class="service-card__link">Demander un devis →</a>
        </article>
      </div>
    </div>
  </section>

  <section class="section" style="background:var(--grey-bg)">
    <div class="container" style="text-align:center; max-width:640px">
      <span class="section__tag">Prêt à former votre équipe ?</span>
      <h2 class="section__title">Formations adaptées à votre secteur</h2>
      <p class="section__lead">Chaque formation est personnalisée selon votre type d'établissement, votre effectif et vos contraintes opérationnelles.</p>
      <a href="<?php echo si_url(); ?>#contact" class="btn btn--primary btn--lg">Demander un devis gratuit</a>
    </div>
  </section>
</main>

<?php get_footer();
