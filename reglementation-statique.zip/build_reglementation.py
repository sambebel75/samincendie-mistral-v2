#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Générateur de pages statiques — Réglementation Sam Incendie
Entrée  : data.json (extrait de l'objet DATA de reglementation.html)
Sortie  : dossier reglementation/ (hub + 118 pages) + fragments sitemap/llms
Usage   : python3 build_reglementation.py
"""
import json, os, html, re, datetime

DATA = json.load(open('data.json', encoding='utf-8'))
OUT = 'reglementation'
SITE = 'https://samincendie.fr'
TODAY = datetime.date.today().isoformat()
os.makedirs(OUT, exist_ok=True)

RELATED = {
    'MS': ['EL','EC','GC','DF'], 'GE': ['CO','AM','MS'], 'CO': ['DF','AM','GE'],
    'EL': ['EC','GC','MS'], 'EC': ['EL','MS'], 'DF': ['CO','CH','MS'],
    'PI': ['GN','PE','GE'], 'SEE': ['GE','GN'],
}

def slug(code):
    return re.sub(r'[^a-z0-9]+', '-', code.lower()).strip('-')

def page_url(cat, code):
    return f'{cat}-{slug(code)}.html'

def esc(s):
    return html.escape(s or '', quote=True)

def meta_desc(art, catlabel):
    d = (art.get('intro') or f"{art['title']}. Texte réglementaire — {catlabel}.").strip()
    d = re.sub(r'<[^>]+>', '', d)
    return (d[:152] + '…') if len(d) > 155 else d

# ---------------------------------------------------------------- CSS partagée
CSS = """
:root{--ink:#1a1a2e;--muted:#5a6270;--bg:#f7f5f2;--card:#fff;--line:#e5e1da;--accent:#C0392B}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Georgia,'Times New Roman',serif;background:var(--bg);color:var(--ink);line-height:1.7}
a{color:var(--accent)}
.topbar{background:#fff;border-bottom:1px solid var(--line);padding:.7rem 1rem;font-family:system-ui,sans-serif}
.topbar .in{max-width:960px;margin:auto;display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap}
.topbar .logo{font-weight:700;color:var(--ink);text-decoration:none;font-size:1.05rem}
.topbar .logo span{color:var(--accent)}
.topbar nav a{margin-left:1rem;text-decoration:none;color:var(--muted);font-size:.9rem}
.crumbs{max-width:960px;margin:1rem auto 0;padding:0 1rem;font-family:system-ui,sans-serif;font-size:.82rem;color:var(--muted)}
.crumbs a{color:var(--muted);text-decoration:none}
.crumbs a:hover{color:var(--accent)}
main{max-width:960px;margin:1rem auto 3rem;padding:0 1rem}
.head-card{background:var(--card);border:1px solid var(--line);border-left:5px solid var(--cat,#C0392B);border-radius:10px;padding:1.4rem 1.6rem;margin-bottom:1.2rem}
.badge{display:inline-block;font-family:system-ui,sans-serif;font-size:.72rem;font-weight:700;letter-spacing:.05em;color:#fff;background:var(--cat,#C0392B);border-radius:4px;padding:.15rem .55rem;margin-bottom:.6rem;text-transform:uppercase}
.badge-new{background:#27AE60;margin-left:.4rem}
h1{font-size:1.55rem;line-height:1.3}
.sub{color:var(--muted);font-family:system-ui,sans-serif;font-size:.92rem;margin-top:.3rem}
.intro{margin-top:.8rem}
.lf{font-family:system-ui,sans-serif;font-size:.85rem;margin-top:.8rem}
.toc{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:1rem 1.4rem;margin-bottom:1.2rem;font-family:system-ui,sans-serif;font-size:.9rem}
.toc strong{display:block;margin-bottom:.4rem}
.toc ol{margin-left:1.2rem}
.toc li{margin:.2rem 0}
.tools{font-family:system-ui,sans-serif;font-size:.85rem;margin-bottom:.8rem}
.tools button{background:none;border:1px solid var(--line);border-radius:6px;padding:.3rem .7rem;cursor:pointer;color:var(--muted)}
details{background:var(--card);border:1px solid var(--line);border-radius:10px;margin-bottom:.8rem}
summary{cursor:pointer;padding:1rem 1.3rem;font-family:system-ui,sans-serif;font-weight:600;list-style:none;display:flex;justify-content:space-between;gap:1rem;align-items:baseline}
summary::-webkit-details-marker{display:none}
summary .ref{font-weight:400;font-size:.8rem;color:var(--muted);white-space:nowrap}
summary::after{content:"▸";color:var(--muted);transition:.15s}
details[open] summary::after{transform:rotate(90deg)}
.body{padding:0 1.4rem 1.2rem;border-top:1px solid var(--line)}
.body p{margin:.9rem 0}
.art-para-num{font-family:system-ui,sans-serif;font-weight:700;color:var(--cat,#C0392B)}
.related,.cta,.pager{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:1.1rem 1.4rem;margin-top:1.2rem;font-family:system-ui,sans-serif}
.related a{margin-right:.8rem}
.cta{border-left:5px solid var(--accent)}
.cta a{display:inline-block;margin:.35rem 1rem .1rem 0;font-weight:600}
.pager{display:flex;justify-content:space-between;gap:1rem;font-size:.9rem}
.pager a{text-decoration:none}
footer{border-top:1px solid var(--line);background:#fff;font-family:system-ui,sans-serif;font-size:.85rem;color:var(--muted);padding:1.2rem 1rem;text-align:center}
/* hub */
.cat-card{background:var(--card);border:1px solid var(--line);border-left:5px solid var(--cat);border-radius:10px;padding:1.3rem 1.5rem;margin-bottom:1.2rem}
.cat-card h2{font-size:1.2rem}
.group{margin-top:.8rem;font-family:system-ui,sans-serif}
.group h3{font-size:.8rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin-bottom:.4rem}
.chips a{display:inline-block;font-size:.83rem;border:1px solid var(--line);border-radius:6px;padding:.22rem .6rem;margin:0 .35rem .4rem 0;text-decoration:none;color:var(--ink)}
.chips a:hover{border-color:var(--cat);color:var(--cat)}
.chips b{color:var(--cat)}
@media(max-width:600px){h1{font-size:1.25rem}summary{padding:.8rem 1rem}.body{padding:0 1rem 1rem}}
"""

def header(depth=''):
    return f"""<header class="topbar"><div class="in">
  <a class="logo" href="../index.html">Sam <span>Incendie</span></a>
  <nav><a href="index.html">Réglementation</a><a href="../faq-securite-incendie-erp.html">FAQ</a><a href="../produits.html">Produits</a><a href="../index.html#contact">Devis gratuit</a></nav>
</div></header>"""

FOOTER = f"""<footer>Sam Incendie — Expert sécurité incendie ERP, certifié SSIAP 3 · <a href="../mentions-legales.html">Mentions légales</a> · Textes présentés à titre documentaire, seule la version Légifrance fait foi. Mise à jour : {TODAY}</footer>"""

def cta_block():
    return """<div class="cta"><strong>Besoin d'appliquer ces textes à votre établissement ?</strong><br>
<a href="../kit-gratuit.html">Checklist gratuite — 10 obligations</a>
<a href="../produits.html">Kit conformité 5e catégorie — 19 €</a>
<a href="../audit.html">Audit terrain sur devis</a></div>"""

def breadcrumb_schema(items):
    lis = [{"@type":"ListItem","position":i+1,"name":n,"item":u} for i,(n,u) in enumerate(items)]
    return json.dumps({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":lis}, ensure_ascii=False)

# ---------------------------------------------------------------- pages chapitres
sitemap_urls, llms_lines = [], []

for cat, catdata in DATA.items():
    catlabel = catdata['label']
    color = catdata['color']
    codes = list(catdata['articles'].keys())
    for i, code in enumerate(codes):
        art = catdata['articles'][code]
        fn = page_url(cat, code)
        url = f'{SITE}/reglementation/{fn}'
        title_txt = f"{code} — {art['title']}"
        page_title = f"{title_txt} | {catlabel.split('—')[0].strip()} | Sam Incendie"
        desc = meta_desc(art, catlabel)
        chaps = art.get('chapters', [])

        toc = ''.join(f'<li><a href="#s{j}">{esc(c["title"])}</a></li>' for j, c in enumerate(chaps))
        sections = []
        for j, c in enumerate(chaps):
            paras = ''.join(f'<p>{t}</p>' for t in c.get('text', []))
            op = ' open' if j == 0 else ''
            ref = f'<span class="ref">{esc(c.get("ref",""))}</span>' if c.get('ref') else ''
            sections.append(f'<details id="s{j}"{op}><summary><h2 style="font-size:1rem;display:inline">{esc(c["title"])}</h2>{ref}</summary><div class="body">{paras}</div></details>')

        rel = [r for r in RELATED.get(code, []) if r in codes]
        related_html = ''
        if rel:
            links = ''.join(f'<a href="{page_url(cat,r)}">{esc(r)} — {esc(catdata["articles"][r]["title"])}</a>' for r in rel)
            related_html = f'<div class="related"><strong>Voir aussi :</strong><br>{links}</div>'

        prev_a = f'<a href="{page_url(cat,codes[i-1])}">← {esc(codes[i-1])}</a>' if i > 0 else '<span></span>'
        next_a = f'<a href="{page_url(cat,codes[i+1])}">{esc(codes[i+1])} →</a>' if i < len(codes)-1 else '<span></span>'
        isnew = '<span class="badge badge-new">Nouveau</span>' if art.get('isNew') else ''
        lf = f'<p class="lf">Texte officiel : <a href="{esc(art["legifrance"])}" rel="noopener" target="_blank">Légifrance</a></p>' if art.get('legifrance') else ''

        bc = breadcrumb_schema([("Accueil", SITE+"/"), ("Réglementation", SITE+"/reglementation/"), (catlabel.split('—')[0].strip(), SITE+"/reglementation/#"+cat), (code, url)])
        webpage = json.dumps({"@context":"https://schema.org","@type":"WebPage","name":title_txt,"description":desc,"url":url,"dateModified":TODAY,"isPartOf":{"@type":"WebSite","name":"Sam Incendie","url":SITE},"about":{"@type":"Thing","name":f"Réglementation sécurité incendie — {catlabel}"},"author":{"@type":"Person","name":"Sam Incendie","url":SITE+"/sam-incendie.html"}}, ensure_ascii=False)

        doc = f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(page_title)}</title>
<meta name="description" content="{esc(desc)}">
<link rel="canonical" href="{url}">
<meta property="og:title" content="{esc(title_txt)} — Sam Incendie">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:type" content="article">
<meta property="og:image" content="{SITE}/img/og-image.png">
<link rel="stylesheet" href="style.css">
<style>:root{{--cat:{color}}}</style>
<script type="application/ld+json">{bc}</script>
<script type="application/ld+json">{webpage}</script>
</head>
<body>
{header()}
<nav class="crumbs" aria-label="Fil d'Ariane"><a href="../index.html">Accueil</a> › <a href="index.html">Réglementation</a> › <a href="index.html#{cat}">{esc(catlabel.split('—')[0].strip())}</a> › <strong>{esc(code)}</strong></nav>
<main>
<div class="head-card">
  <span class="badge">{esc(catlabel.split('—')[0].strip())}</span>{isnew}
  <h1>{esc(title_txt)}</h1>
  <p class="sub">{esc(art.get('sub',''))}</p>
  <p class="intro">{esc(art.get('intro',''))}</p>
  {lf}
</div>
<div class="toc"><strong>Sommaire</strong><ol>{toc}</ol></div>
<div class="tools"><button onclick="document.querySelectorAll('details').forEach(d=>d.open=true)">Tout déplier</button> <button onclick="document.querySelectorAll('details').forEach(d=>d.open=false)">Tout replier</button></div>
{''.join(sections)}
{related_html}
{cta_block()}
<div class="pager">{prev_a}{next_a}</div>
</main>
{FOOTER}
</body>
</html>"""
        open(f'{OUT}/{fn}', 'w', encoding='utf-8').write(doc)
        sitemap_urls.append((url, '0.75'))
        llms_lines.append(f'- [{code} — {art["title"]}]({url})')

# ---------------------------------------------------------------- hub
cat_cards = []
for cat, catdata in DATA.items():
    codes_set = set(catdata['articles'].keys())
    groups = []
    seen = set()
    for g in catdata.get('sidebar', []):
        chips = []
        for row in g.get('rows', []):
            for code in row.get('codes', []):
                if code in codes_set and code not in seen:
                    seen.add(code)
                    t = catdata['articles'][code]['title']
                    chips.append(f'<a href="{page_url(cat,code)}"><b>{esc(code)}</b> {esc(t[:38])}</a>')
        if chips:
            groups.append(f'<div class="group"><h3>{esc(g["group"])}</h3><div class="chips">{"".join(chips)}</div></div>')
    # codes non listés dans la sidebar
    rest = [c for c in catdata['articles'] if c not in seen]
    if rest:
        chips = ''.join(f'<a href="{page_url(cat,c)}"><b>{esc(c)}</b> {esc(catdata["articles"][c]["title"][:38])}</a>' for c in rest)
        groups.append(f'<div class="group"><h3>Autres textes</h3><div class="chips">{chips}</div></div>')
    cat_cards.append(f"""<section class="cat-card" id="{cat}" style="--cat:{catdata['color']}">
<h2>{esc(catdata['label'])}</h2>
<p class="sub">{esc(catdata.get('intro',''))}</p>
{''.join(groups)}
</section>""")

n_pages = len(sitemap_urls)
hub_url = f'{SITE}/reglementation/'
hub_bc = breadcrumb_schema([("Accueil", SITE+"/"), ("Réglementation", hub_url)])
hub_schema = json.dumps({"@context":"https://schema.org","@type":"CollectionPage","name":"Réglementation sécurité incendie — textes consultables","url":hub_url,"description":f"{n_pages} chapitres réglementaires sécurité incendie consultables en ligne : ERP (arrêté du 25 juin 1980), IGH, habitation, code du travail, ICPE.","dateModified":TODAY,"isPartOf":{"@type":"WebSite","name":"Sam Incendie","url":SITE}}, ensure_ascii=False)

hub = f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Réglementation sécurité incendie ERP, IGH, HAB, ICPE — textes 2026 | Sam Incendie</title>
<meta name="description" content="{n_pages} chapitres réglementaires sécurité incendie consultables gratuitement : ERP (GN, CO, MS, PE…), IGH, habitation, code du travail, ICPE. Textes à jour 2026.">
<link rel="canonical" href="{hub_url}">
<meta property="og:title" content="Réglementation sécurité incendie — {n_pages} textes consultables">
<meta property="og:description" content="ERP, IGH, HAB, BUP/ERT, ICPE : toute la réglementation incendie en ligne, gratuite et à jour.">
<meta property="og:url" content="{hub_url}">
<meta property="og:type" content="website">
<meta property="og:image" content="{SITE}/img/og-image.png">
<link rel="stylesheet" href="style.css">
<script type="application/ld+json">{hub_bc}</script>
<script type="application/ld+json">{hub_schema}</script>
</head>
<body>
{header()}
<nav class="crumbs" aria-label="Fil d'Ariane"><a href="../index.html">Accueil</a> › <strong>Réglementation</strong></nav>
<main>
<div class="head-card">
<h1>Réglementation sécurité incendie — {n_pages} textes consultables</h1>
<p class="intro">Base documentaire gratuite et à jour : règlement ERP (arrêté du 25 juin 1980 modifié), IGH/IMH, bâtiments d'habitation, code du travail (BUP/ERT), ICPE et textes complémentaires. Chaque chapitre est consultable en texte intégral, avec lien vers la version officielle Légifrance.</p>
</div>
{''.join(cat_cards)}
{cta_block()}
</main>
{FOOTER}
</body>
</html>"""
open(f'{OUT}/index.html', 'w', encoding='utf-8').write(hub)
open(f'{OUT}/style.css', 'w', encoding='utf-8').write(CSS)

# ---------------------------------------------------------------- fragments
with open('sitemap-fragment.xml', 'w', encoding='utf-8') as f:
    f.write(f'  <!-- ===== RÉGLEMENTATION ({n_pages} chapitres) ===== -->\n')
    f.write(f'  <url><loc>{hub_url}</loc><lastmod>{TODAY}</lastmod><changefreq>monthly</changefreq><priority>0.9</priority></url>\n')
    for u, p in sitemap_urls:
        f.write(f'  <url><loc>{u}</loc><lastmod>{TODAY}</lastmod><changefreq>monthly</changefreq><priority>{p}</priority></url>\n')

with open('llms-fragment.txt', 'w', encoding='utf-8') as f:
    f.write('## Base réglementaire consultable (texte intégral)\n\n')
    f.write(f'- [Hub réglementation — {n_pages} chapitres ERP/IGH/HAB/BUP/ICPE]({hub_url})\n')
    for cat, catdata in DATA.items():
        f.write(f'\n### {catdata["label"]}\n')
        for code, art in catdata['articles'].items():
            f.write(f'- [{code} — {art["title"]}]({SITE}/reglementation/{page_url(cat,code)})\n')

print(f'✓ {n_pages} pages + hub + style.css générés dans {OUT}/')
print('✓ sitemap-fragment.xml et llms-fragment.txt créés')
