# Déploiement — Corpus réglementaire en pages statiques

## Ce que contient le livrable

```
reglementation/           → à copier tel quel à la racine du site
├── index.html            → hub (6 catégories, 118 chapitres liés)
├── style.css             → feuille unique partagée
└── 118 pages HTML        → une par chapitre (erp-co.html, igh-gh.html…)
sitemap-fragment.xml      → 119 <url> à coller dans sitemap.xml (avant </urlset>)
llms-fragment.txt         → section à coller dans llms.txt (après « Ressources principales »)
build_reglementation.py   → générateur : relancer après toute mise à jour du corpus
data.json                 → tes données réglementaires extraites du JS (source du générateur)
```

## Étapes de mise en ligne (30 min)

1. **Copier le dossier `reglementation/`** à la racine du projet Cloudflare Pages. URLs finales : `samincendie.fr/reglementation/` et `samincendie.fr/reglementation/erp-co.html`, etc.
2. **Sitemap** : coller le contenu de `sitemap-fragment.xml` dans `sitemap.xml`, juste avant `</urlset>`.
3. **llms.txt** : coller le contenu de `llms-fragment.txt` après la section « Ressources principales ».
4. **Ancienne page** : sur `reglementation.html`, ajouter en haut un bandeau « 📖 Consulter les textes en version indexable → /reglementation/ ». Tu peux garder l'explorateur interactif tel quel — les deux coexistent sans conflit (canonicals distincts). À terme, une redirection 301 de `reglementation.html` vers `/reglementation/` concentrera l'autorité sur les nouvelles pages.
5. **Search Console** : soumettre le sitemap mis à jour et demander l'indexation du hub.

## Mise à jour du corpus

Quand tu ajoutes ou modifies un texte : mets à jour `data.json` (même structure que ton objet DATA actuel), puis :

```
python3 build_reglementation.py
```

Tout est régénéré — pages, hub, fragments sitemap et llms — avec la date du jour en `dateModified`.

## Ce que ça change pour le GEO

- Avant : 867 mots visibles, 1,93 Mo de JS illisible pour GPTBot, ClaudeBot, PerplexityBot.
- Après : ~1,8 million de caractères de texte réglementaire en HTML brut, répartis sur 118 pages de longue traîne (« article CO 38 ERP », « IT 246 encloisonnement », « GN 6 manifestations exceptionnelles »…), chacune avec canonical, breadcrumb, schema, lien Légifrance et CTA vers tes offres.
- Chaque page pèse 5 à 120 Ko au lieu de 2 Mo pour l'ensemble : chargement quasi instantané, sections repliables pour la lecture.

## Rappel — à faire AVANT pour que ça serve (audit C2/C3)

1. Désactiver le robots.txt managé Cloudflare (il bloque GPTBot et ClaudeBot en tête de fichier).
2. `X-Robots-Tag: noindex` sur `*.pages.dev`.
3. Créer `404.html` à la racine.

Sans ces trois corrections, les nouvelles pages resteront partiellement invisibles pour les crawlers IA.
